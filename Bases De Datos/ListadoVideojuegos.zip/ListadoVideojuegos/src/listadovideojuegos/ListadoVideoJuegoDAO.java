/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadovideojuegos;

import java.util.ArrayList;

/**
 *
 * @author usuari
 */
public class ListadoVideoJuegoDAO {
    ArrayList<Videojuego> listado;

    public ListadoVideoJuegoDAO() {
        listado = new ArrayList<>();
    }
    
    
    
    /**
     * videogame add to list
     * @param add videogame to add to list
     * @return true if the game is add ok.
     */
    public boolean add(Videojuego add)
    {
        if (listado.contains(add))
        {
            return false;
        }
        else
        {
            ShowGamesJdbcMySql.insertANewGame(add);
            return listado.add(add);
        }
        
    }
    
    
    /**
     * delete a videogame
     * @param del videogame that delete of the list
     * @return true if the game is deleted
     */
    public boolean delete(Videojuego del)
    {
        ShowGamesJdbcMySql.deleteAGame(del);
        return listado.remove(del);
    }
    
    /**
     * delete the game in the option choose
     * @param pos position to delete
     * @return  the object delete, if ok, null if the game it's not delete
     */
    public Videojuego delete(int pos)
    {
        
        return listado.remove(pos);
    }

    public ArrayList<Videojuego> getListado() {
        return listado;
    }

    public void setListado(ArrayList<Videojuego> listado) {
        this.listado = listado;
    }
    
    /**
     * change the title of the videogame
     * @param upd the videogame that change the title
     * @param new_title the title to change
     * @return true if the videogame changed it's title.
     */
    public boolean changeName(Videojuego upd, String new_title)
    {
        int pos = listado.indexOf(upd);
        
        if (pos!=-1)
        {
            listado.get(pos).setNombre(new_title);
            return true;
        }
        else
            return false;
    }
    
    
    /**
     * search the text, into the title of the game
     * @param title_find text to find
     * @return List that contains all the games with the text search
     */
    public ArrayList<Videojuego> findName(String title_find)
    {
        ArrayList<Videojuego> find = new ArrayList<>();
        
        for (Videojuego search : listado) {
            if(search.getNombre().contains(title_find))
            {
                find.add(search);
            }
        }
        return find;
    }

    int getNumItems() {
        return listado.size();
    }
    
}
